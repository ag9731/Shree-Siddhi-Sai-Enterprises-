import React from 'react'
import aboutBg from "../../../assets/coverHero.png"
const ClientHero = () => {
  return (
    
      <div className='relative w-full h-[250px]' >
  <img src={aboutBg} className='object-cover w-full h-full mix-blend-multiply' alt="Background Image"/>
  <div className=''></div>
</div>
    
  )
}

export default ClientHero
