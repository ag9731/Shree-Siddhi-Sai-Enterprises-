import React from 'react'
import contactBg from "../../assets/coverHero.png"
const ContactHero = () => {
  return (
    
    <div className='relative w-full h-[250px]' >
  <img src={contactBg} className='object-cover w-full h-full mix-blend-multiply' alt="Background Image"/>
  <div className=''></div>
</div>
    
  )
}

export default ContactHero
